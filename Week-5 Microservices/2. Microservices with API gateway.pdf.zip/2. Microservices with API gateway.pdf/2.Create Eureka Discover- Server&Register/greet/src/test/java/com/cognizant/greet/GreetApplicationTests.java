package com.cognizant.greet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreetApplicationTests {

	@Test
	void contextLoads() {
	}

}
