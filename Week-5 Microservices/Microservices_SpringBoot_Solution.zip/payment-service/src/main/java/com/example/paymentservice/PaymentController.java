
package com.example.paymentservice;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.reactive.function.client.WebClient;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/payment")
public class PaymentController {
    private final WebClient webClient;
    public PaymentController(WebClient.Builder builder) {
        this.webClient = builder.baseUrl("https://slow-third-party.com").build();
    }
    @GetMapping("/process")
    @CircuitBreaker(name = "paymentCB", fallbackMethod = "fallbackPayment")
    public Mono<String> processPayment() {
        return webClient.get().uri("/process").retrieve().bodyToMono(String.class);
    }
    public Mono<String> fallbackPayment(Throwable t) {
        return Mono.just("Fallback triggered: " + t.getMessage());
    }
}
